# Description of package - https://github.com/YetAnotherPackageInstaller/packages
echo "This is a test"
