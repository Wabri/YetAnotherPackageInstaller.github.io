cd ~
git clone https://github.com/YetAnotherPackageInstaller/YAPI.git yapi --depth 1
cd YAPI
python3 install.py
