# Rambox workspace browser - https://rambox.pro
sudo apt install gconf2
wget -O rambox.deb https://github.com/ramboxapp/community-edition/releases/download/0.6.2/Rambox-0.6.2-linux-amd64.deb
sudo dpkg -i rambox.deb
rm -r rambox.deb
