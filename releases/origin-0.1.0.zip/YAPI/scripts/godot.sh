# Godot the game engine open source - https://godotengine.org/
wget -O godot.zip https://downloads.tuxfamily.org/godotengine/3.0.6/Godot_v3.0.6-stable_x11.64.zip
unzip godot.zip
sudo mv Godot_* /usr/local/bin/godot
