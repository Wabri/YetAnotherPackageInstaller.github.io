# GitKraken Git Client and Glo Boards to build epic software - https://www.gitkraken.com/
wget -O gitkraken.deb release.gitkraken.com/linux/gitkraken-amd64.deb
sudo dpkg -i gitkraken.deb
rm -r gitkraken.deb
