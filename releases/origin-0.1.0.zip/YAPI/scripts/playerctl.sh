# Playerctl command-line controller and library - https://github.com/acrisci/playerctl
wget -O playerctl.deb https://github.com/acrisci/playerctl/releases/download/v0.6.1/playerctl-0.6.1_amd64.deb
sudo dpkg -i playerctl.deb
rm -r playerctl.deb
