# Discord voice and text chat - https://discordapp.com/
wget -O discord.deb https://discordapp.com/api/download?platform=linux&format=deb
sudo dpkg -i discord.deb
rm -r discord.deb
