## Packages Supported:
<!--readme_update start packages -->
- Playerctl - Playerctl command-line controller and library - https://github.com/acrisci/playerctl
- Discord - Discord chat vocale e testuale - https://discordapp.com/
- Mailspring - The best mail client - https://getmailspring.com/
- Spotify - Spotify client music for all - https://www.spotify.com
- Idea - IntelliJ IDEA Community edition - https://www.jetbrains.com/idea/
- Gitkraken - GitKraken Git Client and Glo Boards to build epic software - https://www.gitkraken.com/
- Googlechrome - Google Chrome browser - https://www.google.it/chrome/
- Rambox - Rambox workspace browser - https://rambox.pro
- Skype - Skype for linux instant chat and VoIP - https://www.skype.com/
- Nvidiadriver - NVIDIA driver support of Geforce 4xx and higher GPUs - https://wiki.debian.org/NvidiaGraphicsDrivers
- Light - Light GNU/Linux application to control backlights - http://haikarainen.github.io/light
- Oh-my-zsh - zsh + oh-my-zsh - https://ohmyz.sh/
- Virtualbox - VirtualBox is a general-purpose full virtualizer for x86 hardware - https://www.virtualbox.org
- Steam - Steam ultimate entertainment platform - https://store.steampowered.com/about
- Pycharm - Pycharm Community edition - https://www.jetbrains.com/pycharm/
- Dropbox - Dropbox cloud storage - https://www.dropbox.com/
- I3gaps - i3 gaps is i3 with more features - https://github.com/Airblader/i3
- Eclipseinstaller - Eclipse IDE installer - https://www.eclipse.org/
- Atom - Atom Text Editor - https://atom.io/
- Slack - Slack can help your team work together and get things done - https://slack.com/
- Nodejs - NodeJs JavaScript runtime - https://github.com/nodesource/distributions#installation-instructions
- Javajdk11 - Java jdk 11 with path setup - https://www.oracle.com/technetwork/java/javase/downloads/index.html
<!--readme_update end packages -->
