# Slack can help your team work together and get things done - https://slack.com/
wget -O slack.deb https://downloads.slack-edge.com/linux_releases/slack-desktop-3.3.3-amd64.deb
sudo dpkg -i slack.deb
rm -r slack.deb
