# Skype for linux instant chat and VoIP - https://www.skype.com/
wget -O skype.deb https://go.skype.com/skypeforlinux-64.deb
sudo dpkg -i skype.deb
rm -r skype.deb
