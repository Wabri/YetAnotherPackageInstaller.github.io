# Description of package - https://github.com/YetAnotherPackageInstaller/YAPI
echo "Hello world!"
