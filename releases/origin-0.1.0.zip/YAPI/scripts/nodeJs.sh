# NodeJs JavaScript runtime - https://github.com/nodesource/distributions#installation-instructions
curl -sL https://deb.nodesource.com/setup_6.x | sudo bash -
sudo apt install -y nodejs
