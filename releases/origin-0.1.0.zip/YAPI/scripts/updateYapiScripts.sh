# Update scripts from Github - https://github.com/Wabri/YAPI
rm -r scripts
git clone https://github.com/Wabri/YAPI.git --depth 1
mv YAPI/scripts .
sudo rm -r YAPI
